KHAN PERGOLA WEBSITE

Files:
- index.html
- style.css
- project-1.jpeg
- project-2.jpeg

The site is a responsive one-page business website for Khan Pergola in Marsden Park.
It includes:
- Hero section
- Pergolas, decks and patios services
- Project gallery
- About section
- Phone/text contact buttons
- Mobile menu

To put it online for free:
1. Create a free account on GitHub.
2. Create a new repository.
3. Upload all four files.
4. Turn on GitHub Pages in the repository's Settings > Pages.
5. Your website will receive a free github.io web address.

Before publishing, replace/add:
- More project photos
- Service areas
- Email address (if desired)
- Any licence/insurance details you want displayed
- Customer reviews/testimonials
